from setuptools import setup

setup(name='delete-your-pdf',
    version='0.0.1',
    description='Crop, Rotate, and extract text from your PDFs so you can delete them',
    author='James Steinberg',
    author_email='jamespsteinberg@gmail.com',
    url='https://github.com/DareFail/delete-your-pdf',
    packages=['delete-your-pdf'],
    install_requires=['pypdfium2', 'pillow'],
)